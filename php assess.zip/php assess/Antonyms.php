<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Antonyms</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

<div>
    <h2>Add Antonyms Here</h2>
    <div>
        <input type="text" name="antbar" id="antsearch">
    </div>
    <div>
        <input type="file" name="antfile" id="antFiled">
    </div>
    <div>
       <button class="btn btn-primary" id="antbtn">Add</button>
    </div>
    <div>
       <button class="btn btn-danger" id="backbtn">Back</button>
    </div>
</div>


    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>