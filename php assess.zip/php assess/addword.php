<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Addword</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div style="margin-top:10%">
        <h1 style="text-align:center">Add Word Here</h1>

        <div style="justify-content:center;text-align:center;">
            <input type="text" name="searchword" style="width:400px;height:50px">
        </div>
        <div class="mt-4" style="justify-content:center;text-align:center">
            <input type="file" name="choosefile">
        </div>
        <div style="justify-content:center;text-align:center;margin-top:30px">
            <button class="btn btn-primary">Add</button>
        </div>
    </div>

    <div>
        <button class="btn btn-danger mt-5">Back</button>
    </div>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>