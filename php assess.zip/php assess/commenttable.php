<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>comment table</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div>
        <h3>COMMENTS TABLE</h3>
        <div>
            <div>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">WORDS ID</th>
                        <th scope="col">COMMENT</th>
                        <th scope="col">USER</th>
                        <th scope="col">STATUS</th>
                        <th scope="col">ACTION</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>GOOD!..</td>
                        <td>chulbull pandey</td>
                        <td>1</td>
                        <td>
                            <button class="btn btn-info">Approve</button>
                            <button class="btn btn-warning">DisApprove</button>
                            <button class="btn btn-danger">Delete</button>
                        </td>
                    </tr>

                </tbody>
            </table>
            </div>
        </div>
    </div>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>