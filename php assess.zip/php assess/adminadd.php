<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Add</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

<div>
    <h3>ADD WORD HERE</h3>
    <div>
        <input type="text" name="adminaddword" id="adminAddword" placeholder="Enter the word">
    </div>
    <div>
        <input type="file" name="adminaddfile" id="adminAddfile">
    </div>
    <div>
       <button class="btn btn-primary">Add</button>
    </div>
</div>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>