<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Synonyms</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

    <section class="row justify-content-center d-flex mt-5">

        <form class="mt-5  col-lg-8">
            <h2 class="mt-5 ms-5 text-danger fs-1">Add Synonyms Here</h2>
            <div class="mb-3 mt-5">
                <input type="text" class="form-control w-75" name="syncbar" id="syncsearch" placeholder="Enter the word">
            </div>
            <div class="mb-3 mt-5">
                <input type="file" class="form-control w-75" name="syncfile" id="syncFiled">
            </div>
            <button type="submit" class="btn btn-primary mt-4">Add</button>

        </form>
    </section>
    <div class="ms-5" style="margin-top:400px">
        <button class="btn btn-danger" id="backbtn">Back</button>

    </div>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>