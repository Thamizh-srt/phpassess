<?php
include("./config/config.php");
// extract($_REQUEST);
// define variables and set to empty values
// $nameErr = $emailErr =  $passwordErr = "";
// $name = $email =  $password = "";

// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     if (empty($_POST["rusername"]) ||empty($_POST["ruseremail"])|| empty($_POST["ruserpass"]) ) {
//         $nameErr = "Name is required";
//     } else {
//         $name = ($_POST["rusername"]);
//         // check if name only contains letters and whitespace
//         if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
//             $nameErr = "Only letters and white space allowed";
//         }
//     }

//     if (empty($_POST["ruseremail"])) {
//         $emailErr = "Email is required";
//     } else {
//         $email = ($_POST["ruseremail"]);
//         // check if e-mail address is well-formed
//         if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
//             $emailErr = "Invalid email format";
//         }
//     }

//     if (empty($_POST["ruserpass"])) {
//         $passwordErr = "Password is required";
//     } else {
//         $password = ($_POST["ruserpass"]);
//         // check if password is correct
//         if (strlen($password) > 8) {
//             $passwordErr = "Given password should be min 8 characters";
//         } else {
//             $password = $_POST["ruserpass"];
//         }
//     }
// }

if (isset($_POST['register'])) {
    $reg_name = $_POST['rusername'];
    $reg_email = $_POST['ruseremail'];
    $reg_password = $_POST['ruserpass'];
    $con_password = md5($reg_password);
    $fname = $_FILES['ruserpic']['name'];
    $ex = explode('.', $fname);
    $img_ext = strtolower(end($ex));

    if ($img_ext == 'jpg' || $img_ext == 'jpeg' || $img_ext == 'png') {

        $dir = "./assets/Img";
        $newfname = $reg_name . '.' . $img_ext;
        $profilepic_path = $dir . '/' . $newfname;
        move_uploaded_file($_FILES['ruserpic']['tmp_name'], $profilepic_path);
        // Inserting details into database
        $query = "INSERT  INTO handlers(handler_name,handler_email,handler_password,handler_profile) VALUES ('$reg_name','$reg_email','$con_password','$profilepic_path')";
        $result = mysqli_query($conn, $query);
        if ($result) {
            header("location:login.php");
        } else {
            echo mysqli_error($conn);
        }
    } else {
        echo "You have choose.$img_ext . please choose png or jpg or jpeg file";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>
    <section>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#" style="font-size:40px;font-weight:600">DICTIONARY</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 ms-auto">
                        <li class="nav-item">
                            <a class="btn btn-success fs-3" id="loginbtn" href="login.php">Login</a>

                        </li>
                        <li class="nav-item">
                            <a class="btn btn-primary ms-5 fs-3" id="registerbtn" href="register.php">Register</a>
                        </li>

                </div>
            </div>
        </nav>
    </section>


    <section class="justify-content-center d-flex mt-5">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
            <div class="mt-5">
                <h1 class="text-danger">REGISTER FORM</h1>
                <div class="mb-3 mt-4">
                    <label for="inputname" class="form-label text-light fs-4">User Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control w-100" id="inputname" name="rusername" placeholder="Enter username" required>
                    <!-- <span class="error"><?php echo $nameErr; ?></span> -->
                </div>
                <div class="mb-3 mt-4">
                    <label for="inputemail" class="form-label text-light fs-4">User Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control w-100" id="inputemail" name="ruseremail" placeholder="Enter the Email" required>
                    <!-- <span class="error"><?php echo $emailErr; ?></span> -->
                </div>
                <div class="mb-3 mt-4">
                    <label for="inputpass" class="form-label text-light fs-4">User Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control w-100" id="inputpass" name="ruserpass" placeholder="Enter your password" required>
                    <!-- <span class="error"><?php echo $passwordErr; ?></span> -->
                </div>
                <div class="mb-3 mt-4">
                    <label for="inputpic" class="form-label text-light fs-4">User Profilepic<span class="text-danger">*</span></label>
                    <input type="file" class="form-control w-100" id="inputpic" name="ruserpic" required>
                    <!-- <span class="error"><?php echo $passwordErr; ?></span> -->
                </div>
                <div>
                    <button type="submit" class="btn btn-danger fs-4" name="register">Register</button>
                </div>
            </div>
        </form>

    </section>




    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>