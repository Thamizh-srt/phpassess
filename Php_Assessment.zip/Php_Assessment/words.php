<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get words</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="d-flex">
        <div>
            <input type="text" name="meansearch">
        </div>
        <button class="btn btn-success">Search</button>
        <div class="d-flex ms-auto">
            <button class="btn btn-primary">+</button>
            <button class="btn btn-danger">Logout</button>
            <button class="btn btn-success">Back</button>
        </div>
    </div>
    <div>
        <table class="table borderless">
            <thead>
                <tr>
                    <th scope="col">Word:</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row"><img src="./assets/img.jfif" alt=""></th>

                </tr>
                <tr>
                    <th scope="row">
                        <p>Synonyms:kamaraj,Vijay,<button class="btn btn-danger">+</button></p>
                        <p>Antonyms:Uma,<button class="btn btn-danger">+</button></p>
                    </th>


                </tr>
                <tr>
                    <th scope="row">-Add Comments Here-
                        <p><input type="text" id="comment" name="commentbox"></p>
                        <button class="btn btn-primary">Post</button>
                    </th>
                </tr>
                <tr>
                    <th scope="row">- Comments -
                        <p>:[vijay]</p>
                        <p>Good!...</p>
                    </th>
                </tr>
            </tbody>
        </table>
    </div>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>

</body>

</html>