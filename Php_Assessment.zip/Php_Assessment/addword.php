<?php
// session_start();
include("./config/config.php");

if (isset($_POST['addBtn'])) {
    $userid = $_SESSION['user_id'];
    $get_word = $_POST['addword'];
    // $get_wordimg = $_POST['wordImg'];

    $filename = $_FILES['wordImg']['name'];
    $exp = explode('.', $filename);
    $img_ex = strtolower(end($exp));

    if ($img_ex == 'jpg' || $img_ex == 'jpeg' || $img_ex == 'png') {

        $dir = "./assets/Img";
        $newfilename = $get_word . '.' . $img_ex;
        $profile_path = $dir . '/' . $newfilename;
        move_uploaded_file($_FILES['wordImg']['tmp_name'], $profile_path);

        $link = "INSERT INTO words(word_name,word_img,word_status,handler_id) VALUES('$get_word',' $profile_path','0','$userid') ";
        $query = mysqli_query($conn, $link);
        if ($query) {
            header("location:index.php");
        } else {
            echo mysqli_error($conn);
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Addword</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>
    <section class="justify-content-center d-flex mt-5">
        <form class="mt-5" method="post" enctype="multipart/form-data">
            <h1 style="margin-top:200px;margin-left:70px">Add Word Here</h1>
            <div class="mb-3 mt-5">
                <input type="text" class="form-control" style="width:500px;height:70px" name="addword">
            </div>
            <div class="mb-3 mt-4">
                <input type="file" class="form-control w-100" name="wordImg">
            </div>
            <button class="btn btn-primary w-50 fs-5" type="submit" name="addBtn" value="success">Add</button>
        </form>
    </section>

    <div>
        <a class="btn btn-danger mt-5 ms-5 fs-5">Back</a>
    </div>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>